# Pypi

# My Image Processor

Um pacote Python simples para processamento de imagens.

## Instalação

Instale usando pip:

```bash
pip install my_image_processor
