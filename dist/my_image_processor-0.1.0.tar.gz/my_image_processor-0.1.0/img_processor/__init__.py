from .core import resize_image
